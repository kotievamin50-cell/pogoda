/**
 * Утилиты для работы с погодными данными
 * Чистые функции для форматирования и преобразования
 */

/**
 * Получить URL иконки погоды
 * @param {string} iconCode - Код иконки от OpenWeather
 * @param {number} size - Множитель размера (1, 2, 4)
 * @returns {string} URL иконки
 */
export const getWeatherIcon = (iconCode, size = 2) => {
    return `https://openweathermap.org/img/wn/${iconCode}@${size}x.png`;
  };
  
  /**
   * Определить направление ветра по градусам
   * @param {number} degrees - Градусы (0-360)
   * @returns {string} Направление ветра
   */
  export const getWindDirection = (degrees) => {
    if (degrees === undefined || degrees === null) return '—';
    
    const directions = ['С', 'СВ', 'В', 'ЮВ', 'Ю', 'ЮЗ', 'З', 'СЗ'];
    const normalizedDegrees = (degrees + 360) % 360;
    const index = Math.round(normalizedDegrees / 45) % 8;
    return directions[index];
  };
  
  /**
   * Конвертировать гектопаскали в мм рт. ст.
   * @param {number} hPa - Давление в гектопаскалях
   * @returns {number} Давление в мм рт. ст.
   */
  export const getPressureInMmHg = (hPa) => {
    if (!hPa) return 0;
    return Math.round(hPa * 0.750062);
  };
  
  /**
   * Получить уровень УФ-индекса
   * @param {number} uv - Значение УФ-индекса
   * @returns {Object} Информация об уровне УФ
   */
  export const getUVIndex = (uv) => {
    if (uv === undefined || uv === null) {
      return { level: 'Нет данных', color: '#6b7280', advice: 'Нет данных', value: 0 };
    }
    
    if (uv < 3) return { 
      level: 'Низкий', 
      color: '#10b981', 
      advice: 'Защита не требуется', 
      value: uv 
    };
    if (uv < 6) return { 
      level: 'Умеренный', 
      color: '#f59e0b', 
      advice: 'Крем SPF 15-30, шляпа', 
      value: uv 
    };
    if (uv < 8) return { 
      level: 'Высокий', 
      color: '#ef4444', 
      advice: 'Крем SPF 30-50, избегайте солнца с 11 до 16', 
      value: uv 
    };
    if (uv < 11) return { 
      level: 'Очень высокий', 
      color: '#7c3aed', 
      advice: 'Крем SPF 50+, оставайтесь в тени', 
      value: uv 
    };
    return { 
      level: 'Экстремальный', 
      color: '#000000', 
      advice: 'Оставайтесь в помещении', 
      value: uv 
    };
  };
  
  /**
   * Получить текстовое описание качества воздуха
   * @param {number} aqi - Индекс качества воздуха (1-5)
   * @returns {string} Текстовое описание
   */
  export const getAirQualityText = (aqi) => {
    const levels = {
      1: 'Отличное',
      2: 'Хорошее', 
      3: 'Удовлетворительное',
      4: 'Плохое',
      5: 'Очень плохое'
    };
    return levels[aqi] || 'Нет данных';
  };
  
  /**
   * Получить цвет для индикатора качества воздуха
   * @param {number} aqi - Индекс качества воздуха
   * @returns {string} HEX-цвет
   */
  export const getAirQualityColor = (aqi) => {
    const colors = {
      1: '#10b981', // зеленый
      2: '#3b82f6', // синий
      3: '#f59e0b', // желтый
      4: '#ef4444', // красный
      5: '#7c3aed'  // фиолетовый
    };
    return colors[aqi] || '#6b7280';
  };
  
  /**
   * Получить рекомендации по одежде на основе погоды
   * @param {Object} weather - Объект погоды
   * @param {string} units - Единицы измерения ('metric' или 'imperial')
   * @returns {string[]} Массив рекомендаций
   */
  export const getClothingRecommendations = (weather, units = 'metric') => {
    if (!weather || !weather.main) return ['Нет данных'];
    
    const temp = weather.main.temp;
    const condition = weather.weather[0]?.main?.toLowerCase() || '';
    const wind = weather.wind?.speed || 0;
    const humidity = weather.main.humidity || 0;
    
    const recommendations = [];
    
    // Температурные рекомендации
    if (units === 'imperial') {
      // Конвертация из Фаренгейта
      if (temp < 32) recommendations.push('Термобелье', 'Пуховик', 'Варежки');
      else if (temp < 50) recommendations.push('Теплая куртка', 'Шапка');
      else if (temp < 68) recommendations.push('Куртка', 'Свитер');
      else if (temp < 77) recommendations.push('Легкая кофта', 'Джинсы');
      else recommendations.push('Шорты', 'Футболка');
    } else {
      // Метрическая система
      if (temp < 0) recommendations.push('Термобелье', 'Пуховик', 'Варежки');
      else if (temp < 10) recommendations.push('Теплая куртка', 'Шапка');
      else if (temp < 20) recommendations.push('Куртка', 'Свитер');
      else if (temp < 25) recommendations.push('Легкая кофта', 'Джинсы');
      else recommendations.push('Шорты', 'Футболка');
    }
    
    // Погодные условия
    if (condition.includes('rain') || condition.includes('drizzle')) {
      recommendations.push('Дождевик', 'Непромокаемая обувь');
    }
    
    if (condition.includes('snow') || condition.includes('sleet')) {
      recommendations.push('Теплые сапоги', 'Шарф');
    }
    
    if (condition.includes('clear') || condition.includes('sun')) {
      recommendations.push('Солнцезащитные очки');
    }
    
    // Ветер
    if (wind > 10) {
      recommendations.push('Ветровка', 'Прическа по погоде');
    }
    
    // Влажность
    if (humidity > 80) {
      recommendations.push('Легкая дышащая одежда');
    } else if (humidity < 30) {
      recommendations.push('Увлажняющий крем');
    }
    
    // Убираем дубликаты
    return [...new Set(recommendations)];
  };
  
  /**
   * Рассчитать точку росы
   * @param {number} temperature - Температура в °C
   * @param {number} humidity - Влажность в %
   * @returns {number} Точка росы в °C
   */
  export const calculateDewPoint = (temperature, humidity) => {
    if (!temperature || !humidity) return 0;
    
    const a = 17.27;
    const b = 237.7;
    const alpha = ((a * temperature) / (b + temperature)) + Math.log(humidity / 100);
    return (b * alpha) / (a - alpha);
  };
  
  /**
   * Получить описание видимости
   * @param {number} visibility - Видимость в метрах
   * @returns {string} Описание видимости
   */
  export const getVisibilityDescription = (visibility) => {
    if (!visibility) return 'Нет данных';
    
    if (visibility >= 10000) return 'Отличная';
    if (visibility >= 5000) return 'Хорошая';
    if (visibility >= 2000) return 'Умеренная';
    if (visibility >= 1000) return 'Плохая';
    return 'Очень плохая';
  };
  
  /**
   * Конвертировать скорость ветра
   * @param {number} speed - Скорость в м/с
   * @param {string} units - Желаемые единицы ('metric' или 'imperial')
   * @returns {Object} Конвертированная скорость и единицы
   */
  export const convertWindSpeed = (speed, units = 'metric') => {
    if (!speed) return { value: 0, unit: 'м/с' };
    
    if (units === 'imperial') {
      return {
        value: Math.round(speed * 2.237 * 10) / 10, // м/с → миль/ч
        unit: 'миль/ч'
      };
    }
    
    return {
      value: Math.round(speed * 10) / 10,
      unit: 'м/с'
    };
  };
  
  /**
   * Получить эмодзи для погодных условий
   * @param {string} condition - Погодное условие
   * @param {boolean} isDay - День или ночь
   * @returns {string} Эмодзи
   */
  export const getWeatherEmoji = (condition, isDay = true) => {
    const emojis = {
      Clear: isDay ? '☀️' : '🌙',
      Clouds: '☁️',
      Rain: '🌧️',
      Snow: '❄️',
      Thunderstorm: '⛈️',
      Drizzle: '🌦️',
      Mist: '🌫️',
      Smoke: '💨',
      Haze: '😶‍🌫️',
      Dust: '💨',
      Fog: '🌁',
      Sand: '🌪️',
      Ash: '🌋',
      Squall: '💨',
      Tornado: '🌪️'
    };
    
    return emojis[condition] || (isDay ? '🌤️' : '🌃');
  };
  
  /**
   * Рассчитать индекс теплового стресса (Heat Index)
   * @param {number} temp - Температура в °C
   * @param {number} humidity - Влажность в %
   * @returns {number} Индекс теплового стресса
   */
  export const calculateHeatIndex = (temp, humidity) => {
    if (temp < 27) return temp;
    
    // Формула для °C
    const T = temp;
    const R = humidity;
    
    const HI = -8.784695 + 
      1.61139411 * T + 
      2.338549 * R - 
      0.14611605 * T * R - 
      0.012308094 * T * T - 
      0.016424828 * R * R + 
      0.002211732 * T * T * R + 
      0.00072546 * T * R * R - 
      0.000003582 * T * T * R * R;
    
    return Math.round(HI * 10) / 10;
  };
  
  /**
   * Проверить, подходит ли погода для активности
   * @param {Object} weather - Данные погоды
   * @param {string} activity - Активность
   * @returns {boolean} Подходит ли
   */
  export const isWeatherGoodForActivity = (weather, activity) => {
    if (!weather) return false;
    
    const temp = weather.main.temp;
    const condition = weather.weather[0]?.main?.toLowerCase() || '';
    const wind = weather.wind?.speed || 0;
    const rainProbability = weather.pop || 0;
    
    const activities = {
      'Пикник': temp > 18 && temp < 30 && !condition.includes('rain') && wind < 8,
      'Пробежка': temp > 5 && temp < 30 && rainProbability < 30,
      'Велосипед': temp > 10 && temp < 35 && !condition.includes('rain') && wind < 10,
      'Пляж': temp > 25 && condition.includes('clear'),
      'Лыжи': temp < 0 && condition.includes('snow'),
      'Поход': temp > 10 && temp < 28 && rainProbability < 40,
      'Рыбалка': !condition.includes('thunderstorm') && wind < 12,
      'Фотография': true // Всегда хорошо для фото
    };
    
    return activities[activity] || false;
  };