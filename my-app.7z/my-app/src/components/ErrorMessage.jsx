import React from 'react';
import { motion } from 'framer-motion';

const ErrorMessage = ({ message }) => {
  return (
    <motion.div
      className="status-message error"
      initial={{ scale: 0.8, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ type: 'spring', damping: 10 }}
    >
      <p>⚠️ {message}</p>
    </motion.div>
  );
};

export default ErrorMessage;