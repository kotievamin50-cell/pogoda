import React from 'react';
import { motion } from 'framer-motion';

const Recommendations = ({ weather, activities, units }) => {
  if (!weather) return null;

  const getWearRecommendation = () => {
    const temp = weather.main.temp;
    const condition = weather.weather[0].main.toLowerCase();
    const wind = weather.wind.speed;
    
    let recommendations = [];
    
    if (temp < 0) {
      recommendations.push('Теплая куртка', 'Шапка', 'Перчатки');
    } else if (temp < 10) {
      recommendations.push('Куртка', 'Шарф');
      if (condition.includes('rain')) recommendations.push('Зонт');
    } else if (temp < 20) {
      recommendations.push('Свитер', 'Ветровка');
    } else if (temp < 25) {
      recommendations.push('Футболка', 'Легкая кофта');
    } else {
      recommendations.push('Шорты', 'Футболка', 'Солнцезащитные очки');
    }
    
    if (wind > 10) recommendations.push('Ветровка');
    if (condition.includes('rain')) recommendations.push('Дождевик', 'Непромокаемая обувь');
    if (weather.main.humidity > 80) recommendations.push('Легкая одежда');
    
    return [...new Set(recommendations)];
  };

  const getUVRecommendation = () => {
    // Для демо - определяем примерный УФ-индекс по времени и облачности
    const now = new Date().getHours();
    const isDay = now >= 6 && now <= 20;
    const clouds = weather.clouds.all;
    
    if (!isDay || clouds > 80) return 'Низкий (защита не нужна)';
    if (clouds > 50) return 'Умеренный (крем SPF 15-30)';
    return 'Высокий (крем SPF 30-50, головной убор)';
  };

  const wearItems = getWearRecommendation();
  const uvLevel = getUVRecommendation();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="recommendations"
    >
      <h3>Рекомендации</h3>
      
      <div className="recommendations-grid">
        {/* Что надеть */}
        <div className="recommendation-card">
          <div className="rec-icon">👕</div>
          <h4>Что надеть</h4>
          <div className="wear-items">
            {wearItems.map((item, i) => (
              <span key={i} className="wear-tag">{item}</span>
            ))}
          </div>
        </div>
        
        {/* Активности */}
        {activities.length > 0 && (
          <div className="recommendation-card">
            <div className="rec-icon">🚴</div>
            <h4>Идеально для</h4>
            <div className="activity-items">
              {activities.map((activity, i) => (
                <span key={i} className="activity-tag">{activity}</span>
              ))}
            </div>
          </div>
        )}
        
        {/* Защита от солнца */}
        <div className="recommendation-card">
          <div className="rec-icon">☀️</div>
          <h4>УФ-защита</h4>
          <p className="uv-level">{uvLevel}</p>
        </div>
        
        {/* Влажность */}
        <div className="recommendation-card">
          <div className="rec-icon">💧</div>
          <h4>Влажность</h4>
          <p className="humidity-level">
            {weather.main.humidity > 80 ? 'Высокая, пейте воду' : 
             weather.main.humidity < 40 ? 'Низкая, увлажняйте кожу' : 'Комфортная'}
          </p>
        </div>
      </div>
    </motion.div>
  );
};

export default Recommendations;