import React from 'react';
import { motion } from 'framer-motion';

const AirQuality = ({ data }) => {
  const getAQILevel = (aqi) => {
    const levels = {
      1: { label: 'Отличное', color: '#10b981', emoji: '😊' },
      2: { label: 'Хорошее', color: '#3b82f6', emoji: '🙂' },
      3: { label: 'Удовлетворительное', color: '#f59e0b', emoji: '😐' },
      4: { label: 'Плохое', color: '#ef4444', emoji: '😷' },
      5: { label: 'Очень плохое', color: '#7c3aed', emoji: '🤢' }
    };
    return levels[aqi] || { label: 'Нет данных', color: '#6b7280', emoji: '🤔' };
  };

  const getPollutantInfo = (name, value) => {
    const pollutants = {
      co: { name: 'CO', unit: 'μg/m³', desc: 'Угарный газ' },
      no: { name: 'NO', unit: 'μg/m³', desc: 'Оксид азота' },
      no2: { name: 'NO₂', unit: 'μg/m³', desc: 'Диоксид азота' },
      o3: { name: 'O₃', unit: 'μg/m³', desc: 'Озон' },
      so2: { name: 'SO₂', unit: 'μg/m³', desc: 'Диоксид серы' },
      pm2_5: { name: 'PM2.5', unit: 'μg/m³', desc: 'Мелкие частицы' },
      pm10: { name: 'PM10', unit: 'μg/m³', desc: 'Крупные частицы' },
      nh3: { name: 'NH₃', unit: 'μg/m³', desc: 'Аммиак' }
    };
    return pollutants[name] || { name, unit: '', desc: '' };
  };

  if (!data) return null;

  const aqiLevel = getAQILevel(data.main.aqi);
  const components = data.components;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="air-quality"
    >
      <div className="aqi-header">
        <h3>Качество воздуха</h3>
        <div 
          className="aqi-badge"
          style={{ backgroundColor: aqiLevel.color }}
        >
          <span className="aqi-emoji">{aqiLevel.emoji}</span>
          <span className="aqi-label">{aqiLevel.label}</span>
          <span className="aqi-index">AQI {data.main.aqi}</span>
        </div>
      </div>
      
      <div className="pollutants-grid">
        {Object.entries(components).map(([key, value]) => {
          const info = getPollutantInfo(key, value);
          return (
            <div key={key} className="pollutant">
              <div className="pollutant-name">{info.name}</div>
              <div className="pollutant-value">{Math.round(value)} {info.unit}</div>
              <div className="pollutant-desc">{info.desc}</div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
};

export default AirQuality;