import React from 'react';
import { motion } from 'framer-motion';
import { formatDate } from '../utils/formatDate';

const Forecast = ({ forecast }) => {
  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="forecast-container"
    >
      <div className="forecast-grid">
        {forecast.map((day, i) => (
          <motion.div
            key={i}
            className="forecast-day"
            whileHover={{ y: -5 }}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1, type: 'spring', stiffness: 300 }}
          >
            <div className="date">{formatDate(day.date)}</div>
            <img
              src={`https://openweathermap.org/img/wn/${day.weather.icon}@2x.png`}
              alt={day.weather.description}
              className="forecast-icon"
            />
            <div className="temps">
              <span className="max">{Math.round(day.temp_max)}°</span>
              <span className="min">{Math.round(day.temp_min)}°</span>
            </div>
            <div className="humidity">💧 {day.humidity}%</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default Forecast;