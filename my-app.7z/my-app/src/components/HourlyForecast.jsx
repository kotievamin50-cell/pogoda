import React from 'react';
import { motion } from 'framer-motion';
import { formatTime } from '../utils/formatDate';

const HourlyForecast = ({ hourly, units }) => {
  const getUnitSymbol = () => units === 'metric' ? '°C' : '°F';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="hourly-forecast"
    >
      <h3>Почасовой прогноз</h3>
      <div className="hourly-scroll">
        {hourly.map((hour, i) => (
          <motion.div
            key={i}
            className="hour-item"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
          >
            <div className="hour-time">{formatTime(hour.dt)}</div>
            <img
              src={`https://openweathermap.org/img/wn/${hour.weather[0].icon}.png`}
              alt={hour.weather[0].description}
              className="hour-icon"
            />
            <div className="hour-temp">{Math.round(hour.main.temp)}{getUnitSymbol()}</div>
            <div className="hour-pop">💧 {Math.round(hour.pop * 100)}%</div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default HourlyForecast;