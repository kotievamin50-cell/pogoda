import React from 'react';
import { motion } from 'framer-motion';

const WeatherCard = ({ title, value, icon }) => {
  return (
    <motion.div
      className="weather-card"
      whileHover={{ scale: 1.03 }}
      transition={{ type: 'spring', stiffness: 400 }}
    >
      <div className="card-icon">{icon}</div>
      <div className="card-title">{title}</div>
      <div className="card-value">{value}</div>
    </motion.div>
  );
};

export default WeatherCard;