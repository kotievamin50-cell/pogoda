import { useState, useEffect } from 'react';

const API_KEY = '6b89a4d73b2877d91a3dd853052bf45f';
const BASE_URL = 'https://api.openweathermap.org/data/2.5';
const AIR_QUALITY_URL = 'http://api.openweathermap.org/data/2.5/air_pollution';

export const useWeather = () => {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [hourlyForecast, setHourlyForecast] = useState([]);
  const [airQuality, setAirQuality] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [favorites, setFavorites] = useState([]);
  const [units, setUnits] = useState('metric');
  const [activeActivities, setActiveActivities] = useState([]);

  // Загрузка избранных из localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('weatherFavorites');
    if (savedFavorites) {
      const parsed = JSON.parse(savedFavorites);
      setFavorites(parsed);
    }
  }, []);

  // Загрузить настройки пользователя
  useEffect(() => {
    const savedUnits = localStorage.getItem('weatherUnits');
    if (savedUnits) setUnits(savedUnits);
  }, []);

  const saveFavorites = (newFavorites) => {
    setFavorites(newFavorites);
    localStorage.setItem('weatherFavorites', JSON.stringify(newFavorites));
  };

  const fetchWeather = async (cityName) => {
    if (!cityName?.trim()) return;

    setLoading(true);
    setError('');

    try {
      // Текущая погода
      const weatherUrl = `${BASE_URL}/weather?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=${units}&lang=ru`;
      const weatherResponse = await fetch(weatherUrl);
      if (!weatherResponse.ok) throw new Error('Город не найден');
      const weatherData = await weatherResponse.json();

      // Прогноз на 5 дней
      const forecastUrl = `${BASE_URL}/forecast?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=${units}&lang=ru`;
      const forecastResponse = await fetch(forecastUrl);
      if (!forecastResponse.ok) throw new Error('Ошибка загрузки прогноза');
      const forecastData = await forecastResponse.json();

      // Качество воздуха
      const aqUrl = `${AIR_QUALITY_URL}?lat=${weatherData.coord.lat}&lon=${weatherData.coord.lon}&appid=${API_KEY}`;
      const aqResponse = await fetch(aqUrl);
      if (aqResponse.ok) {
        const aqData = await aqResponse.json();
        setAirQuality(aqData.list[0]);
      }

      setWeather(weatherData);
      processForecastData(forecastData);
      setCity(cityName);
      checkActivities(weatherData);
      
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const processForecastData = (data) => {
    const dailyData = {};
    const now = new Date();

    // Фильтруем только будущие дни
    data.list.forEach(item => {
      const itemDate = new Date(item.dt * 1000);
      if (itemDate < now) return;
      
      const date = itemDate.toLocaleDateString('ru-RU');
      if (!dailyData[date]) {
        dailyData[date] = {
          date: item.dt,
          temp_min: item.main.temp_min,
          temp_max: item.main.temp_max,
          humidity: item.main.humidity,
          weather: item.weather[0],
          wind_speed: item.wind.speed,
          pop: item.pop,
          items: []
        };
      }
      dailyData[date].items.push(item);
      dailyData[date].temp_min = Math.min(dailyData[date].temp_min, item.main.temp_min);
      dailyData[date].temp_max = Math.max(dailyData[date].temp_max, item.main.temp_max);
    });

    const dailyForecast = Object.values(dailyData).slice(0, 5);
    const hourly = data.list.slice(0, 8);
    
    setForecast(dailyForecast);
    setHourlyForecast(hourly);
  };

  const checkActivities = (weatherData) => {
    const activities = [];
    const temp = weatherData.main.temp;
    const condition = weatherData.weather[0].main.toLowerCase();
    const wind = weatherData.wind.speed;

    if (temp > 20 && condition.includes('clear')) activities.push('Пикник');
    if (temp > 10 && temp < 25 && wind < 5) activities.push('Пробежка');
    if (temp > 5 && condition.includes('clear')) activities.push('Велосипед');
    if (temp < 15 && condition.includes('rain')) activities.push('Библиотека');
    if (temp < 0 && condition.includes('snow')) activities.push('Лыжи');
    if (condition.includes('clear') || condition.includes('few clouds')) activities.push('Фотография');
    if (temp > 25 && condition.includes('clear')) activities.push('Пляж');

    setActiveActivities(activities.slice(0, 3));
  };

  const toggleFavorite = () => {
    if (!weather || !weather.sys) return;
    
    const cityKey = `${weather.name},${weather.sys.country || 'RU'}`;
    const isFavorite = favorites.some(fav => 
      `${fav.name},${fav.sys?.country || 'RU'}` === cityKey
    );

    let newFavorites;
    if (isFavorite) {
      newFavorites = favorites.filter(fav => 
        `${fav.name},${fav.sys?.country || 'RU'}` !== cityKey
      );
    } else {
      newFavorites = [...favorites, weather];
    }

    saveFavorites(newFavorites);
  };

  const toggleUnits = () => {
    const newUnits = units === 'metric' ? 'imperial' : 'metric';
    setUnits(newUnits);
    localStorage.setItem('weatherUnits', newUnits);
  };

  useEffect(() => {
    if (weather && city) {
      fetchWeather(city);
    }
  }, [units]);

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError('Геолокация не поддерживается');
      return;
    }

    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        const locationUrl = `${BASE_URL}/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=${units}&lang=ru`;
        
        try {
          const response = await fetch(locationUrl);
          if (!response.ok) throw new Error('Ошибка определения местоположения');
          const data = await response.json();
          setWeather(data);
          setCity(data.name);
        } catch (err) {
          setError(err.message);
        } finally {
          setLoading(false);
        }
      },
      (error) => {
        setError('Не удалось получить ваше местоположение');
        setLoading(false);
      }
    );
  };

  return {
    city,
    setCity,
    weather,
    forecast,
    hourlyForecast,
    airQuality,
    loading,
    error,
    favorites,
    units,
    activeActivities,
    fetchWeather,
    toggleFavorite,
    toggleUnits,
    getCurrentLocation
  };
};