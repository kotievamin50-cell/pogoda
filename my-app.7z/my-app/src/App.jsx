import React, { useState } from 'react';
import { useWeather } from './hooks/useWeather';
import SearchBar from './components/SearchBar';
import CurrentWeather from './components/CurrentWeather';
import Forecast from './components/Forecast';
import HourlyForecast from './components/HourlyForecast';
import Loading from './components/Loading';
import ErrorMessage from './components/ErrorMessage';
import WelcomeScreen from './components/WelcomeScreen';
import './App.css';

const App = () => {
  const [activeTab, setActiveTab] = useState('current');
  const [mapView, setMapView] = useState(false);

  const {
    city,
    setCity,
    weather,
    forecast,
    hourlyForecast,
    loading,
    error,
    favorites,
    units,
    fetchWeather,
    toggleFavorite,
    toggleUnits,
    getCurrentLocation
  } = useWeather();

  const handleSearch = (e) => {
    e.preventDefault();
    if (city.trim()) fetchWeather(city.trim());
  };

  const handleSelectCity = (cityName) => {
    setCity(cityName);
    fetchWeather(cityName);
  };

  const handleFavoriteSelect = (cityName) => {
    setCity(cityName);
    fetchWeather(cityName);
  };

  const isCurrent_favorite = weather && favorites.some(fav => 
    `${fav.name},${fav.sys.country}` === `${weather.name},${weather.sys.country}`
  );

  const toggleMapView = () => {
    setMapView(!mapView);
  };

  // Если включен режим "только карта"
  if (mapView && weather) {
    return (
      <div className="fullscreen-map">
        <div className="map-controls">
          <button
            className="map-exit-btn"
            onClick={toggleMapView}
            aria-label="Вернуться к прогнозу погоды"
          >
            <span className="map-btn-icon">←</span>
            <span>Вернуться к погоде</span>
          </button>
          
          <div className="map-control-panel">
            <button 
              className="map-control-btn"
              onClick={() => window.open(`https://yandex.ru/maps/?ll=${weather.coord.lon},${weather.coord.lat}&z=12`, '_blank')}
              title="Открыть в Яндекс.Картах"
            >
              ↗
            </button>
          </div>
        </div>

        <div className="map-info-panel">
          <div className="info-block">
            <h4>📍 Местоположение</h4>
            <div className="value">{weather.name}, {weather.sys.country}</div>
            <div className="sub-value">
              Координаты: {weather.coord.lat.toFixed(4)}, {weather.coord.lon.toFixed(4)}
            </div>
          </div>
          
          <div className="info-block">
            <h4>🌡️ Температура</h4>
            <div className="value">{Math.round(weather.main.temp)}°{units === 'metric' ? 'C' : 'F'}</div>
            <div className="sub-value">
              Ощущается как {Math.round(weather.main.feels_like)}°
            </div>
          </div>
          
          <div className="info-block">
            <h4>🌤️ Погода</h4>
            <div className="value">{weather.weather[0].description}</div>
            <div className="sub-value">
              Влажность: {weather.main.humidity}%
            </div>
          </div>
        </div>

        <iframe
          title="yandex-map-fullscreen"
          src={`https://yandex.ru/map-widget/v1/?ll=${weather.coord.lon},${weather.coord.lat}&z=12&l=map&size=full`}
          width="100%"
          height="100%"
          frameBorder="0"
          allowFullScreen
          loading="lazy"
          className="map-iframe"
        ></iframe>
      </div>
    );
  }

  // Основной режим
  return (
    <div className="app">
      {/* Фоновая карта */}
      {weather && (
        <div className="map-background">
          <iframe
            title="yandex-map"
            src={`https://yandex.ru/map-widget/v1/?ll=${weather.coord.lon},${weather.coord.lat}&z=10&l=map&size=small`}
            width="100%"
            height="100%"
            frameBorder="0"
            allowFullScreen
            aria-hidden="true"
            loading="lazy"
          ></iframe>
          <div className="map-overlay"></div>
        </div>
      )}

      {/* Панель управления справа */}
      <div className="control-panel">
        {weather && (
          <button
            className="map-toggle-btn"
            onClick={toggleMapView}
            aria-label="Показать карту на весь экран"
            title="Перейти к карте местности"
          >
            <span className="map-btn-icon">🗺️</span>
            <span className="map-btn-text">Карта</span>
          </button>
        )}
        
        {/* Кнопки темы */}
        <div className="theme-controls">
          <h4>Тема</h4>
          <div className="theme-buttons">
            <button 
              className="theme-btn active"
              title="Светлая"
              onClick={() => document.body.classList.remove('dark-theme')}
            >
              🌞
            </button>
            <button 
              className="theme-btn"
              title="Темная"
              onClick={() => document.body.classList.add('dark-theme')}
            >
              🌙
            </button>
            <button 
              className="theme-btn"
              title="Авто"
              onClick={() => {
                if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
                  document.body.classList.add('dark-theme');
                } else {
                  document.body.classList.remove('dark-theme');
                }
              }}
            >
              ⚡
            </button>
          </div>
        </div>
      </div>

      <header className="header">
        <h1>🌤️ Прогноз Погоды</h1>
        <p>Узнайте погоду в любом городе мира</p>
      </header>

      <main className="container">
        <SearchBar 
          city={city}
          setCity={setCity}
          onSubmit={handleSearch}
          onGeolocation={getCurrentLocation}
          favorites={favorites}
          onFavoriteSelect={handleFavoriteSelect}
        />

        {error && <ErrorMessage message={error} />}
        {loading && <Loading />}

        {!weather && !loading && !error && (
          <WelcomeScreen onSelectCity={handleSelectCity} />
        )}

        {weather && (
          <>
            <div className="tabs">
              <button
                className={`tab-btn ${activeTab === 'current' ? 'active' : ''}`}
                onClick={() => setActiveTab('current')}
              >
                Сегодня
              </button>
              <button
                className={`tab-btn ${activeTab === 'hourly' ? 'active' : ''}`}
                onClick={() => setActiveTab('hourly')}
              >
                Почасовой
              </button>
              <button
                className={`tab-btn ${activeTab === 'forecast' ? 'active' : ''}`}
                onClick={() => setActiveTab('forecast')}
              >
                На 5 дней
              </button>
            </div>

            <div className="content">
              {activeTab === 'current' && (
                <CurrentWeather 
                  weather={weather}
                  isFavorite={isCurrent_favorite}
                  onToggleFavorite={toggleFavorite}
                  units={units}
                  onToggleUnits={toggleUnits}
                />
              )}
              
              {activeTab === 'hourly' && (
                <HourlyForecast 
                  hourly={hourlyForecast}
                  units={units}
                />
              )}
              
              {activeTab === 'forecast' && (
                <Forecast 
                  forecast={forecast}
                  units={units}
                />
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;