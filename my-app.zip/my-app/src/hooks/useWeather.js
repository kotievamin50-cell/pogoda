import { useState, useEffect } from 'react';

const API_KEY = '6b89a4d73b2877d91a3dd853052bf45f';
const BASE_URL = 'https://api.openweathermap.org/data/2.5'; // ← Исправлено: убраны пробелы!

export const useWeather = () => {
  const [city, setCity] = useState('');
  const [weather, setWeather] = useState(null);
  const [forecast, setForecast] = useState([]);
  const [hourlyForecast, setHourlyForecast] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [favorites, setFavorites] = useState([]);
  const [units, setUnits] = useState('metric');

  // Загрузка избранных из localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('weatherFavorites');
    if (savedFavorites) {
      const parsed = JSON.parse(savedFavorites);
      setFavorites(parsed);
      console.log('✅ Загружены избранные города из localStorage:', parsed);
    } else {
      console.log('ℹ️ Нет сохранённых избранных городов');
    }
  }, []);

  const saveFavorites = (newFavorites) => {
    setFavorites(newFavorites);
    localStorage.setItem('weatherFavorites', JSON.stringify(newFavorites));
    console.log('💾 Сохранены избранные города:', newFavorites);
  };

  const fetchWeather = async (cityName) => {
    if (!cityName?.trim()) {
      console.warn('⚠️ Попытка запроса погоды с пустым названием города');
      return;
    }

    setLoading(true);
    setError('');
    console.log(`📡 Запрос погоды для города: "${cityName}", единицы: ${units}`);

    try {
      // Текущая погода
      const weatherUrl = `${BASE_URL}/weather?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=${units}&lang=ru`;
      console.log('🔗 URL текущей погоды:', weatherUrl);

      const weatherResponse = await fetch(weatherUrl);
      if (!weatherResponse.ok) {
        const errMsg = `Город не найден: ${weatherResponse.status} ${weatherResponse.statusText}`;
        console.error('❌ Ошибка текущей погоды:', errMsg);
        throw new Error('Город не найден');
      }

      const weatherData = await weatherResponse.json();
      console.log('🌤️ Получены данные текущей погоды:', weatherData);

      // Прогноз на 5 дней
      const forecastUrl = `${BASE_URL}/forecast?q=${encodeURIComponent(cityName)}&appid=${API_KEY}&units=${units}&lang=ru`;
      console.log('🔗 URL прогноза:', forecastUrl);

      const forecastResponse = await fetch(forecastUrl);
      if (!forecastResponse.ok) {
        const errMsg = `Ошибка прогноза: ${forecastResponse.status} ${forecastResponse.statusText}`;
        console.error('❌ Ошибка прогноза:', errMsg);
        throw new Error('Ошибка загрузки прогноза');
      }

      const forecastData = await forecastResponse.json();
      console.log('📅 Получены данные прогноза (первые 3 записи):', forecastData.list.slice(0, 3));

      setWeather(weatherData);
      processForecastData(forecastData);
      setCity(cityName);

      console.log('✅ Успешно обновлена погода и прогноз для:', cityName);
    } catch (err) {
      setError(err.message);
      console.error('💥 Критическая ошибка в fetchWeather:', err);
    } finally {
      setLoading(false);
      console.log('⏹️ Завершён запрос погоды (loading = false)');
    }
  };

  const processForecastData = (data) => {
    console.log('⚙️ Обработка прогноза, всего записей:', data.list.length);
    const dailyData = {};

    data.list.forEach(item => {
      const date = new Date(item.dt * 1000).toLocaleDateString('ru-RU');
      if (!dailyData[date]) {
        dailyData[date] = {
          date: item.dt,
          temp_min: item.main.temp_min,
          temp_max: item.main.temp_max,
          humidity: item.main.humidity,
          weather: item.weather[0],
          items: []
        };
      }
      dailyData[date].items.push(item);
      dailyData[date].temp_min = Math.min(dailyData[date].temp_min, item.main.temp_min);
      dailyData[date].temp_max = Math.max(dailyData[date].temp_max, item.main.temp_max);
    });

    const dailyForecast = Object.values(dailyData).slice(0, 6);
    const hourly = data.list.slice(0, 8);

    setForecast(dailyForecast);
    setHourlyForecast(hourly);

    console.log('📊 Обработан прогноз: дней =', dailyForecast.length, ', часов =', hourly.length);
  };

  const toggleFavorite = () => {
    if (!weather) {
      console.warn('⚠️ Невозможно добавить в избранное: погода не загружена');
      return;
    }

    const cityKey = `${weather.name},${weather.sys.country}`;
    const isFavorite = favorites.some(fav => `${fav.name},${fav.sys.country}` === cityKey);

    let newFavorites;
    if (isFavorite) {
      newFavorites = favorites.filter(fav => `${fav.name},${fav.sys.country}` !== cityKey);
      console.log('💔 Удалён из избранного:', cityKey);
    } else {
      newFavorites = [...favorites, weather];
      console.log('❤️ Добавлен в избранное:', cityKey);
    }

    saveFavorites(newFavorites);
  };

  const toggleUnits = () => {
    const newUnits = units === 'metric' ? 'imperial' : 'metric';
    console.log('🔄 Переключение единиц измерения:', units, '→', newUnits);
    setUnits(newUnits);
  };

  // Автоматический перезапрос при смене единиц
  useEffect(() => {
    if (weather && city) {
      console.log('🔁 Перезапрос данных из-за смены единиц измерения');
      fetchWeather(city);
    }
  }, [units]);

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      const msg = 'Геолокация не поддерживается вашим браузером';
      setError(msg);
      console.error('🚫', msg);
      return;
    }

    setLoading(true);
    console.log('📍 Запрос геолокации...');

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        const locationUrl = `${BASE_URL}/weather?lat=${latitude}&lon=${longitude}&appid=${API_KEY}&units=${units}&lang=ru`;
        console.log('🔗 URL по геолокации:', locationUrl);

        try {
          const response = await fetch(locationUrl);
          if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
          }
          const data = await response.json();
          setWeather(data);
          setCity(data.name);
          console.log('🌍 Получена погода по геолокации:', data.name);
        } catch (err) {
          const msg = 'Ошибка определения местоположения';
          setError(msg);
          console.error('💥', msg, err);
        } finally {
          setLoading(false);
          console.log('⏹️ Завершён запрос по геолокации');
        }
      },
      (error) => {
        const msg = 'Не удалось получить ваше местоположение';
        setError(msg);
        setLoading(false);
        console.error('🚫 Ошибка геолокации:', error.message || error);
      }
    );
  };

  return {
    city,
    setCity,
    weather,
    forecast,
    hourlyForecast,
    loading,
    error,
    favorites,
    units,
    fetchWeather,
    toggleFavorite,
    toggleUnits,
    getCurrentLocation
  };
};