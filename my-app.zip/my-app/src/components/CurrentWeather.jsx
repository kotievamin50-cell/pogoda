import React from 'react';
import WeatherCard from './WeatherCard';
import { motion } from 'framer-motion';
import { formatTime } from '../utils/formatDate';

const CurrentWeather = ({ weather, isFavorite, onToggleFavorite, units, onToggleUnits }) => {
  const iconUrl = `https://openweathermap.org/img/wn/${weather.weather[0].icon}@4x.png`;
  
  const getUnitSymbol = () => units === 'metric' ? '°C' : '°F';
  const getSpeedUnit = () => units === 'metric' ? 'м/с' : 'миль/ч';

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="current-weather"
    >
      <div className="weather-header">
        <div className="city-info">
          <h2>
            {weather.name}, {weather.sys.country}
            <button 
              className={`favorite-btn ${isFavorite ? 'active' : ''}`}
              onClick={onToggleFavorite}
              title={isFavorite ? 'Удалить из избранного' : 'Добавить в избранное'}
            >
              {isFavorite ? '★' : '☆'}
            </button>
          </h2>
          <p className="weather-description">{weather.weather[0].description}</p>
        </div>
        
        <button 
          className="units-toggle"
          onClick={onToggleUnits}
          title="Переключить единицы измерения"
        >
          {getUnitSymbol()}
        </button>
      </div>

      <div className="main-weather">
        <img src={iconUrl} alt={weather.weather[0].description} className="main-icon" />
        <div className="temp">{Math.round(weather.main.temp)}{getUnitSymbol()}</div>
        <div className="feels-like">
          Ощущается как {Math.round(weather.main.feels_like)}{getUnitSymbol()}
        </div>
      </div>

      <div className="sun-times">
        <div className="sun-time">
          <span>🌅 Восход</span>
          <span>{formatTime(weather.sys.sunrise)}</span>
        </div>
        <div className="sun-time">
          <span>🌇 Закат</span>
          <span>{formatTime(weather.sys.sunset)}</span>
        </div>
      </div>

      <div className="details-grid">
        <WeatherCard title="Влажность" value={`${weather.main.humidity}%`} icon="💧" />
        <WeatherCard title="Ветер" value={`${weather.wind.speed} ${getSpeedUnit()}`} icon="💨" />
        <WeatherCard title="Давление" value={`${weather.main.pressure} гПа`} icon="🔽" />
        <WeatherCard title="Видимость" value={`${weather.visibility / 1000} км`} icon="👁️" />
      </div>
    </motion.div>
  );
};

export default CurrentWeather;