import React from 'react';
import { motion } from 'framer-motion';

const Loading = () => {
  return (
    <motion.div
      className="status-message"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className="spinner"></div>
      <p>Загружаем погоду...</p>
    </motion.div>
  );
};

export default Loading;