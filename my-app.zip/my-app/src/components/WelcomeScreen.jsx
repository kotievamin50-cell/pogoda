// src/components/WelcomeScreen.jsx
import React from 'react';
import { motion } from 'framer-motion';

const WelcomeScreen = ({ onSelectCity }) => {
  const cities = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань'];

  return (
    <motion.div
      className="welcome-screen"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="cloud-icon">☁️</div>
      <p className="welcome-text">Введите название города для начала</p>
      <div className="suggestions">
        <span>Попробуйте:</span>
        {cities.map((city, i) => (
          <motion.span
            key={i}
            className="suggestion"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onSelectCity(city)}
          >
            {city}
          </motion.span>
        ))}
      </div>
    </motion.div>
  );
};

export default WelcomeScreen;