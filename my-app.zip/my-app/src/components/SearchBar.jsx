import React, { useState } from 'react';
import { motion } from 'framer-motion';

const SearchBar = ({ city, setCity, onSubmit, onGeolocation, favorites, onFavoriteSelect }) => {
  const [showSuggestions, setShowSuggestions] = useState(false);

  const popularCities = ['Москва', 'Санкт-Петербург', 'Новосибирск', 'Екатеринбург', 'Казань'];

  const handleSubmit = (e) => {
    e.preventDefault();
    setShowSuggestions(false);
    onSubmit(e);
  };

  return (
    <div className="search-container">
      <form className="search-bar" onSubmit={handleSubmit}>
        <div className="search-input-wrapper">
          <input
            type="text"
            value={city}
            onChange={(e) => {
              setCity(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            placeholder="Введите город, например: Москва"
            aria-label="Поиск города"
            required
          />
          
          {/* Автодополнение */}
          {showSuggestions && (city || favorites.length > 0) && (
            <motion.div
              className="suggestions-dropdown"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              {favorites.map((fav, i) => (
                <div
                  key={i}
                  className="suggestion-item"
                  onClick={() => {
                    onFavoriteSelect(`${fav.name}, ${fav.sys.country}`);
                    setShowSuggestions(false);
                  }}
                >
                  ⭐ {fav.name}, {fav.sys.country}
                </div>
              ))}
              
              {popularCities
                .filter(popCity => 
                  popCity.toLowerCase().includes(city.toLowerCase()) && 
                  !favorites.some(fav => fav.name === popCity)
                )
                .map((cityName, i) => (
                  <div
                    key={i}
                    className="suggestion-item"
                    onClick={() => {
                      setCity(cityName);
                      setShowSuggestions(false);
                    }}
                  >
                    {cityName}
                  </div>
                ))}
            </motion.div>
          )}
        </div>
        
        <button type="submit" className="search-btn">Найти</button>
        <button 
          type="button" 
          className="geolocation-btn"
          onClick={onGeolocation}
          title="Определить мое местоположение"
        >
          📍
        </button>
      </form>
    </div>
  );
};

export default SearchBar;