import React, { useState } from 'react';
import { useWeather } from './hooks/useWeather';
import SearchBar from './components/SearchBar';
import CurrentWeather from './components/CurrentWeather';
import Forecast from './components/Forecast';
import HourlyForecast from './components/HourlyForecast';
import Loading from './components/Loading';
import ErrorMessage from './components/ErrorMessage';
import WelcomeScreen from './components/WelcomeScreen';
import './App.css';

const App = () => {
  const [activeTab, setActiveTab] = useState('current');
  const [mapView, setMapView] = useState(false); // false = погода, true = только карта

  const {
    city,
    setCity,
    weather,
    forecast,
    hourlyForecast,
    loading,
    error,
    favorites,
    units,
    fetchWeather,
    toggleFavorite,
    toggleUnits,
    getCurrentLocation
  } = useWeather();

  const handleSearch = (e) => {
    e.preventDefault();
    if (city.trim()) fetchWeather(city.trim());
  };

  const handleSelectCity = (cityName) => {
    setCity(cityName);
    fetchWeather(cityName);
  };

  const handleFavoriteSelect = (cityName) => {
    setCity(cityName);
    fetchWeather(cityName);
  };

  const isCurrent_favorite = weather && favorites.some(fav => 
    `${fav.name},${fav.sys.country}` === `${weather.name},${weather.sys.country}`
  );

  const toggleMapView = () => {
    setMapView(!mapView);
  };

  // Если включен режим "только карта" и есть координаты — показываем карту на весь экран
  if (mapView && weather) {
    return (
      <div className="fullscreen-map">
        <button
          className="map-exit-btn"
          onClick={toggleMapView}
          aria-label="Вернуться к прогнозу погоды"
        >
          🌤️ Назад к погоде
        </button>
        <iframe
          title="yandex-map-fullscreen"
          src={`https://yandex.ru/map-widget/v1/?ll=${weather.coord.lon},${weather.coord.lat}&z=10`}
          width="100%"
          height="100%"
          frameBorder="0"
          allowFullScreen
        ></iframe>
      </div>
    );
  }

  // Обычный режим: погода + фоновая карта
  return (
    <div className="app">
      {/* Фоновая карта (только если есть погода) */}
      {weather && (
        <div className="map-background">
          <iframe
            title="yandex-map"
            src={`https://yandex.ru/map-widget/v1/?ll=${weather.coord.lon},${weather.coord.lat}&z=10`}
            width="100%"
            height="100%"
            frameBorder="0"
            allowFullScreen
            aria-hidden="true"
          ></iframe>
        </div>
      )}

      {/* Кнопка переключения режимов (только если есть погода) */}
      {weather && (
        <button
          className="map-toggle-btn"
          onClick={toggleMapView}
          aria-label={mapView ? "Вернуться к прогнозу" : "Показать карту на весь экран"}
        >
          🗺️ Карта
        </button>
      )}

      <header className="header">
        <h1>🌤️ Прогноз Погоды</h1>
        <p>Узнайте погоду в любом городе мира</p>
      </header>

      <main className="container">
        <SearchBar 
          city={city}
          setCity={setCity}
          onSubmit={handleSearch}
          onGeolocation={getCurrentLocation}
          favorites={favorites}
          onFavoriteSelect={handleFavoriteSelect}
        />

        {error && <ErrorMessage message={error} />}
        {loading && <Loading />}

        {!weather && !loading && !error && (
          <WelcomeScreen onSelectCity={handleSelectCity} />
        )}

        {weather && (
          <>
            <div className="tabs">
              <button
                className={`tab-btn ${activeTab === 'current' ? 'active' : ''}`}
                onClick={() => setActiveTab('current')}
              >
                Сегодня
              </button>
              <button
                className={`tab-btn ${activeTab === 'hourly' ? 'active' : ''}`}
                onClick={() => setActiveTab('hourly')}
              >
                Почасовой
              </button>
              <button
                className={`tab-btn ${activeTab === 'forecast' ? 'active' : ''}`}
                onClick={() => setActiveTab('forecast')}
              >
                На 5 дней
              </button>
            </div>

            <div className="content">
              {activeTab === 'current' && (
                <CurrentWeather 
                  weather={weather}
                  isFavorite={isCurrent_favorite}
                  onToggleFavorite={toggleFavorite}
                  units={units}
                  onToggleUnits={toggleUnits}
                />
              )}
              
              {activeTab === 'hourly' && (
                <HourlyForecast 
                  hourly={hourlyForecast}
                  units={units}
                />
              )}
              
              {activeTab === 'forecast' && (
                <Forecast 
                  forecast={forecast}
                  units={units}
                />
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
};

export default App;