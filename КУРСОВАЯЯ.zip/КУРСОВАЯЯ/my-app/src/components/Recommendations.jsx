import React from 'react';
import { motion } from 'framer-motion';

const Recommendations = ({ weather, units }) => {
  if (!weather) return null;

  const getWearRecommendation = () => {
    const temp = weather.main.temp;
    const condition = weather.weather[0].main.toLowerCase();
    const wind = weather.wind.speed;

    let recommendations = [];
    
    // Температурные рекомендации
    if (temp < 0) {
      recommendations.push('Теплая куртка', 'Шапка', 'Перчатки', 'Термобелье');
    } else if (temp < 10) {
      recommendations.push('Куртка', 'Шарф', 'Теплый свитер');
      if (condition.includes('rain')) recommendations.push('Зонт');
    } else if (temp < 20) {
      recommendations.push('Свитер', 'Ветровка', 'Джинсы');
    } else if (temp < 25) {
      recommendations.push('Футболка', 'Легкая кофта', 'Штаны/джинсы');
    } else {
      recommendations.push('Шорты', 'Футболка/майка', 'Солнцезащитные очки', 'Панама/кепка');
    }

    // Ветер
    if (wind > 10) recommendations.push('Ветровка', 'Закрепить волосы');
    
    // Дождь
    if (condition.includes('rain')) {
      recommendations.push('Дождевик/плащ', 'Непромокаемая обувь', 'Водонепроницаемый рюкзак');
    }
    
    // Высокая влажность
    if (weather.main.humidity > 80) recommendations.push('Легкая дышащая одежда', 'Сменная футболка');

    return [...new Set(recommendations)];
  };

  const getUVRecommendation = () => {
    const now = new Date().getHours();
    const isDay = now >= 6 && now <= 20;
    const clouds = weather.clouds.all;

    if (!isDay || clouds > 80) return {
      level: 'Низкий',
      protection: 'Защита не требуется',
      icon: '☁️'
    };
    
    if (clouds > 50) return {
      level: 'Умеренный',
      protection: 'Крем SPF 15-30, очки от солнца',
      icon: '⛅'
    };
    
    return {
      level: 'Высокий',
      protection: 'Крем SPF 30-50, головной убор, солнцезащитные очки',
      icon: '☀️'
    };
  };

  const getActivityRecommendation = () => {
    const temp = weather.main.temp;
    const condition = weather.weather[0].main.toLowerCase();
    
    if (condition.includes('rain') || condition.includes('storm')) {
      return [
        'Посетить музеи или галереи',
        'Сходить в кино или кафе',
        'Заняться домашними делами',
        'Почитать книгу'
      ];
    }
    
    if (temp < 0) {
      return [
        'Катание на лыжах или коньках',
        'Прогулка в зимнем лесу',
        'Посещение спа или бани',
        'Горячий шоколад в уютном кафе'
      ];
    }
    
    if (temp < 15) {
      return [
        'Пешие прогулки в парке',
        'Посещение выставок',
        'Кофе в теплом месте',
        'Фотографирование осенних/весенних пейзажей'
      ];
    }
    
    if (temp < 25) {
      return [
        'Велосипедная прогулка',
        'Пикник на природе',
        'Открытые спортивные площадки',
        'Прогулка по набережной'
      ];
    }
    
    return [
      'Пляжный отдых',
      'Купание в водоеме',
      'Прогулка в тенистых парках',
      'Водные виды спорта',
      'Мороженое и прохладительные напитки'
    ];
  };

  const wearRecommendations = getWearRecommendation();
  const uvInfo = getUVRecommendation();
  const activityRecommendations = getActivityRecommendation();

  return (
    <motion.div 
      className="recommendations-container"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="recommendations-header">
        <h2>👕 Рекомендации на сегодня</h2>
        <p className="location-info">
          {weather.name}, {weather.sys.country} • {Math.round(weather.main.temp)}°{units === 'metric' ? 'C' : 'F'} • {weather.weather[0].description}
        </p>
      </div>

      <div className="recommendations-grid">
        <div className="recommendation-card">
          <h3>👔 Что надеть</h3>
          <ul className="recommendation-list">
            {wearRecommendations.map((item, index) => (
              <li key={index}>
                <span className="check-icon">✓</span>
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div className="recommendation-card">
          <h3>{uvInfo.icon} UV-индекс: {uvInfo.level}</h3>
          <p className="uv-description">{uvInfo.protection}</p>
          
          <div className="weather-conditions">
            <div className="condition-item">
              <span className="condition-icon">💨</span>
              <div>
                <div className="condition-label">Ветер</div>
                <div className="condition-value">{weather.wind.speed} м/с</div>
              </div>
            </div>
            
            <div className="condition-item">
              <span className="condition-icon">💧</span>
              <div>
                <div className="condition-label">Влажность</div>
                <div className="condition-value">{weather.main.humidity}%</div>
              </div>
            </div>
          </div>
        </div>

        <div className="recommendation-card">
          <h3>🎯 Чем заняться</h3>
          <ul className="recommendation-list">
            {activityRecommendations.map((activity, index) => (
              <li key={index}>
                <span className="check-icon">✓</span>
                {activity}
              </li>
            ))}
          </ul>
        </div>

        <div className="recommendation-card full-width">
          <h3>📝 Советы</h3>
          <div className="tips-grid">
            <div className="tip">
              <span className="tip-icon">🌧️</span>
              <div>
                <h4>Если будет дождь</h4>
                <p>Возьмите зонт и наденьте непромокаемую обувь. Планируйте маршрут с укрытиями.</p>
              </div>
            </div>
            
            <div className="tip">
              <span className="tip-icon">❄️</span>
              <div>
                <h4>При низких температурах</h4>
                <p>Одевайтесь слоями. Не забывайте про шапку и перчатки - через голову уходит 30% тепла.</p>
              </div>
            </div>
            
            <div className="tip">
              <span className="tip-icon">☀️</span>
              <div>
                <h4>В солнечную погоду</h4>
                <p>Пейте больше воды. Используйте солнцезащитный крем даже в облачную погоду.</p>
              </div>
            </div>
            
            <div className="tip">
              <span className="tip-icon">💨</span>
              <div>
                <h4>При сильном ветре</h4>
                <p>Закрепите волосы, наденьте ветровку. Будьте осторожны с головными уборами.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default Recommendations;